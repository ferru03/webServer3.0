package com.example;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.StringTokenizer;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JavaHTTPServer implements Runnable{
    // Definisco la Web Root 
    static final File WEB_ROOT = new File("./src/main/resources");
    // Definisco il file predefinito
	static final String DEFAULT_FILE = "index.html";
    // Definisco il file utilizzato quando un file non verrà trovato
	static final String FILE_NOT_FOUND = "404.html";
    // Definisco il file chiamato per un metodo HTTP non supportato
	static final String METHOD_NOT_SUPPORTED = "not_supported.html";
	// Definisco la porta per ascoltare le connessioni
	static final int PORT = 8080;
	
	// Definisco la modalità verbosa
	static final boolean verbose = true;
	
	// Creo un oggetto Socket. Le connessioni client verranno gestite tramite l'oggetto Socket.
	private Socket connect;
	// Costruttore parametrico
	public JavaHTTPServer(Socket c) {
		connect = c;
	}
	
	public static void main(String[] args) {
		try {
			ServerSocket serverConnect= new ServerSocket(PORT);
			System.out.println("Server started.\nListening for connections on port : " + PORT + " ...\n");

			// DESERIALIZZAZIONE: Java Object to JSON
			File file = new File("./src/main/resources/puntiVendita.json");
			ObjectMapper objectMapper = new ObjectMapper();
			PuntiVendita puntiVendita = new PuntiVendita();
			objectMapper.writeValue(file, puntiVendita);
			String stringaPuntiVendita = objectMapper.writeValueAsString(puntiVendita);

			// SERIALIZZAZIONE: JSON to Java Object
			puntiVendita  = objectMapper.readValue(stringaPuntiVendita, PuntiVendita.class);
			puntiVendita = objectMapper.readValue(new File("src/test/resources/puntiVendita.json"), PuntiVendita.class);

			// Ascolto finché l'utente non interrompe l'esecuzione del server
			while (true) {
				JavaHTTPServer myServer = new JavaHTTPServer(serverConnect.accept());
				
				if (verbose) {
					System.out.println("Connecton opened. (" + new Date() + ")");
				}
				
				// Ogni connessione client è gestita in un thread dedicato. La classe implementa Runnable.
				Thread thread = new Thread(myServer);
				thread.start();
			}
			
		} catch (IOException e) {
			System.err.println("Server Connection error : " + e.getMessage());
		}
	}

	@Override
	public void run() {
		// Gestisco la connessione client
		BufferedReader in = null; PrintWriter out = null; BufferedOutputStream dataOut = null;
		String fileRequested = null;
		
		try {
			// Leggo i caratteri dal client tramite input sul socket
			in = new BufferedReader(new InputStreamReader(connect.getInputStream()));
			// Ottengo il flusso di output dei caratteri sul client
			out = new PrintWriter(connect.getOutputStream());
			// Ottengo il flusso di output binario al client (per i dati richiesti)
			dataOut = new BufferedOutputStream(connect.getOutputStream());
			
			// Ottengo la prima riga della richiesta dal client
			String input = in.readLine();
			// Analizzo la richiesta
			StringTokenizer parse = new StringTokenizer(input);
            // Ottengo il metodo HTTP del client
			String method = parse.nextToken().toUpperCase();
			// Ottengo il file richiesto
			fileRequested = parse.nextToken().toLowerCase();
			
			// Controllo per supportare solo i metodi GET e HEAD
			if (!method.equals("GET")  &&  !method.equals("HEAD")) {
				if (verbose) {
					System.out.println("501 Not Implemented : " + method + " method.");
				}
				
				// Restituisco il file non supportato al client
				File file = new File(WEB_ROOT, METHOD_NOT_SUPPORTED);
				int fileLength = (int) file.length();
				String contentMimeType = "text/html";
				// Leggo il contenuto per tornare al client
				byte[] fileData = readFileData(file, fileLength);
					
				// Invio l'intestazioni HTTP con i dati al client
				out.println("HTTP/1.1 501 Not Implemented");
				out.println("Server: Java HTTP Server from SSaurel : 1.0");
				out.println("Date: " + new Date());
				out.println("Content-type: " + contentMimeType);
				out.println("Content-length: " + fileLength);
				out.println(); // Riga vuota tra intestazioni e contenuto
				out.flush(); // Svuota il buffer di output dei caratteri
				// File
				dataOut.write(fileData, 0, fileLength);
				dataOut.flush();
				
			} else {
				// Metodo GET o HEAD
				if (fileRequested.endsWith("/")) {
					System.out.println("File: " + fileRequested);
					out.println("HTTP/1.1 301 File moved and relocated");
					out.println("Server: Java HTTP Server from SSaurel : 1.0");
					out.println("Date: " + new Date());
					out.println("Location: " + "http://localhost:8080/pagina2.html");
					out.println(); // Riga vuota tra intestazioni e contenuto
					out.flush(); // Svuota il buffer di output dei caratteri
				}
				File file = new File(WEB_ROOT, fileRequested);
				int fileLength = (int) file.length();
				String content = getContentType(fileRequested);
				
                // Metodo GET in modo da restituire il contenuto
				if (method.equals("GET")) {
					byte[] fileData = readFileData(file, fileLength);
					
					// Invia inte Invia intestazioni HTTP
					out.println("HTTP/1.1 200 OK");
					out.println("Server: Java HTTP Server from SSaurel : 1.0");
					out.println("Date: " + new Date());
					out.println("Content-type: " + content);
					out.println("Content-length: " + fileLength);
					out.println(); // Riga vuota tra intestazioni e contenuto
					out.flush(); // Svuota il buffer di output dei caratteri
					
					dataOut.write(fileData, 0, fileLength);
					dataOut.flush();
				}
				
				if (verbose) {
					System.out.println("File " + fileRequested + " of type " + content + " returned");
				}
				
			}
			
		} catch (FileNotFoundException fnfe) {
			try {
				fileNotFound(out, dataOut, fileRequested);
			} catch (IOException ioe) {
				System.err.println("Error with file not found exception : " + ioe.getMessage());
			}
			
		} catch (IOException ioe) {
			System.err.println("Server error : " + ioe);
		} finally {
			try {
				in.close();
				out.close();
				dataOut.close();
				connect.close(); // Chiudo la connessione socket
			} catch (Exception e) {
				System.err.println("Error closing stream : " + e.getMessage());
			} 
			
			if (verbose) {
				System.out.println("Connection closed.\n");
			}
		}
	}
	
	private byte[] readFileData(File file, int fileLength) throws IOException {
		FileInputStream fileIn = null;
		byte[] fileData = new byte[fileLength];
		
		try {
			fileIn = new FileInputStream(file);
			fileIn.read(fileData);
		} finally {
			if (fileIn != null) 
				fileIn.close();
		}
		
		return fileData;
	}
	
	// Restituisce i tipi MIME supportati
	private String getContentType(String fileRequested) {
		if (fileRequested.endsWith(".htm")  ||  fileRequested.endsWith(".html")){
			return "text/html";
		}else if(fileRequested.endsWith(".css")){
			return "text/css";
		}else if(fileRequested.endsWith(".jpeg")){
			return "text/jpeg";
		}
		else if(fileRequested.endsWith(".jpg")){
			return "text/jpg";
		}
		else if(fileRequested.endsWith(".png")){
			return "text/png";
		}
		else if(fileRequested.endsWith(".gif")){
			return "text/gif";
		}
		else if(fileRequested.endsWith(".js")){
			return "application/js";
		}
		else if(fileRequested.endsWith(".json")){
			return "application/json";
		}
		else if(fileRequested.endsWith(".xml")){
			return "application/xml";
		}else{
			return "text/plain";
		}
	}
	
	private void fileNotFound(PrintWriter out, OutputStream dataOut, String fileRequested) throws IOException {
		File file = new File(WEB_ROOT, FILE_NOT_FOUND);
		int fileLength = (int) file.length();
		String content = "text/html";
		byte[] fileData = readFileData(file, fileLength);
		
		out.println("HTTP/1.1 404 File Not Found");
		out.println("Server: Java HTTP Server from SSaurel : 1.0");
		out.println("Date: " + new Date());
		out.println("Content-type: " + content);
		out.println("Content-length: " + fileLength);
		out.println(); // Riga vuota tra intestazioni e contenuto
		out.flush(); // Svuota il buffer di output dei caratteri
		
		dataOut.write(fileData, 0, fileLength);
		dataOut.flush();
		
		if (verbose) {
			System.out.println("File " + fileRequested + " not found");
		}
	}
}
